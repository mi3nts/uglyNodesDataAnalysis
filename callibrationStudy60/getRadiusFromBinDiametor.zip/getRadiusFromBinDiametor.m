
function radiusOut = getRadiusFromBins(bins)

radiusOut = diff(bins)/2
end

